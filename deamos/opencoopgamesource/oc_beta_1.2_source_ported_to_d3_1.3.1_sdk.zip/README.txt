INSTALL INSTRUCTIONS:
copy it over a fresh installation of d3sdk
compile it

COPYRIGHT:
-> id software

if ( yourModUses(OPENCOOP) )
{
  pleaseMentionItIn( rand ( CREDITS || WEBPAGE || README ) );
}

nicemice

============================================================

ported to Doom3 1.3.1 by Oneofthe8devilz


if ( YouThinkThatOpenSource(ShouldStayOpenSource) )
{
  pleaseGiveAShoutTo( rand ( OpenCoop Team || LMS Team ) );
}

Oneofthe8devilz